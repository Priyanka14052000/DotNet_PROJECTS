﻿namespace _2002_ExpenseTracking.DataAccess.Implementation
{
    public class Class1
    {

    }
}

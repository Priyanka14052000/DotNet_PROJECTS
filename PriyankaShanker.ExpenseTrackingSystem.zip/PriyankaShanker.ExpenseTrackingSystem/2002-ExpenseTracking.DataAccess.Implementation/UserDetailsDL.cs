﻿using _1001_ExpenseTracking.BusinessModels;
using _2001_ExpenseTracking.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2002_ExpenseTracking.DataAccess.Implementation
{
    public class UserDetailsDL:IUserDetailsDL
    {
        public List<User> GetUserDetails()
        {
            var users = new List<User>()
            {
                new User{Id=Guid.NewGuid(), UserName="Priyanka", FirstName="Priyanka", LastName="Shanker", Department="Development" }
            };
            return users;
        }
    }
}

﻿using _1001_ExpenseTracking.BusinessModels;
using _2001_ExpenseTracking.DataAccess;
using _2002_ExpenseTracking.DataAccess.Implementation;
using _3001_ExpenseTracking.BusinessDomain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3002_ExpenseTracking.BusinessDomain.Implemenation
{
    public class UserDetailsBL: IUserDetailsBL
    {
       public List<User> GetUserDetails()
        {
            IUserDetailsDL userDetailsDL = new UserDetailsDL();
            return userDetailsDL.GetUserDetails();
        }
        public List<User> GetUserDetails1()
        {
            IUserDetailsDL userDetailsDL = new UserDetailsDL();
            return userDetailsDL.GetUserDetails();
        }
    }
}

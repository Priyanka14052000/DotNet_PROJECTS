﻿namespace _3002_ExpenseTracking.BusinessDomain.Implemenation
{
    public class Class1
    {

    }
}

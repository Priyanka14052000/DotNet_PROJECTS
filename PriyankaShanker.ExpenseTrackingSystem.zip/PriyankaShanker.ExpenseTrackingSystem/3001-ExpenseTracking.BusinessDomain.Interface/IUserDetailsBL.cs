﻿using _1001_ExpenseTracking.BusinessModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3001_ExpenseTracking.BusinessDomain.Interface
{
    public interface IUserDetailsBL
    {
        public List<User> GetUserDetails();

        public List<User> GetUserDetails1();

    }
}

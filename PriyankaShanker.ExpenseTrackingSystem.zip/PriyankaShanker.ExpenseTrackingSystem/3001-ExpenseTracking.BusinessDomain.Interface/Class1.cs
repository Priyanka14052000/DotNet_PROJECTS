﻿namespace _3001_ExpenseTracking.BusinessDomain.Interface
{
    public class Class1
    {

    }
}

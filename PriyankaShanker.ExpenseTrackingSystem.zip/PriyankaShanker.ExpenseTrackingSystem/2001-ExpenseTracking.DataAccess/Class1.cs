﻿namespace _2001_ExpenseTracking.DataAccess
{
    public class Class1
    {

    }
}

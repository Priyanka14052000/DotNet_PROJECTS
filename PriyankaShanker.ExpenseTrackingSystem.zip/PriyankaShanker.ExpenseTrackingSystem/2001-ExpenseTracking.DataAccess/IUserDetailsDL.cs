﻿using _1001_ExpenseTracking.BusinessModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001_ExpenseTracking.DataAccess
{
    public  interface IUserDetailsDL
    {
        List<User> GetUserDetails();
    }
}

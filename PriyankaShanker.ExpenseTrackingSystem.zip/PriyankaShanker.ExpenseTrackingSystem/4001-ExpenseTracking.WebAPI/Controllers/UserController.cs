﻿using _1001_ExpenseTracking.BusinessModels;
using _3001_ExpenseTracking.BusinessDomain.Interface;
using _3002_ExpenseTracking.BusinessDomain.Implemenation;
using Microsoft.AspNetCore.Mvc;

namespace _4001_ExpenseTracking.WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<UserController> _logger;
        private readonly IUserDetailsBL _userDetailsBL;

        public UserController(ILogger<UserController> logger, IUserDetailsBL userDetailsBL)
        {
            _logger = logger;
            _userDetailsBL = userDetailsBL;
        }

        [HttpGet(Name = "GetUsers")]
        public List<User> Get()
        {
         
            return _userDetailsBL.GetUserDetails();

        }
    }
}
